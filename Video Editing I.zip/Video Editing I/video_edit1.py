
from moviepy.editor import VideoFileClip

# Load 'toy_plane.mp4'
video = VideoFileClip("toy_plane.mp4")

# basic information of this video
print("filename:", video.filename) # filename
print("duration:", video.duration) # duration in seconds
print("fps:", video.fps) # frames per second
print("size:", video.size) # width x height
## Output:
# filename: toy_plane.mp4
# duration: 4.0
# fps: 25.0
# size: [640, 480]

## Run Video With 2x Speed
# speed it up by 2x
video2 = video.speedx(2.0)
print('video2.duration:', video2.duration)
## Output:
# video2.duration: 2.0

## Save The Video
# Write it to "toy_plane2.mp4"
video2.write_videofile("toy_plane2.mp4")

## Predefined Effects
### Import VFX
import moviepy.video.fx.all as vfx

### Fade In Effect
# fade in over the first 2.0 seconds
fadein = vfx.fadein(video, 2.0)
fadein.write_videofile("toy_plane2_fadein.mp4")

### Fade out:
# fade out over the last 2.0 seconds
fadeout = vfx.fadeout(video, 2.0)
fadeout.write_videofile("toy_plane2_fadeout.mp4")

### Freeze:
# freeze at time 2.0 second for 1.0 second
freeze = vfx.freeze(video, 2.0, 1.0)
freeze.write_videofile("freeze.mp4")

### Time mirror:
# Play the clip backwards
time_mirror = vfx.time_mirror(video)
time_mirror.write_videofile("toy_plane2_time_mirror.mp4")

### Combine All Above Effects
multiple = video
multiple = vfx.time_mirror(multiple) # time mirror
multiple = vfx.freeze(multiple, 2.0, 1.0) # freeze
multiple = vfx.fadein(multiple, 2.0) # fade in
multiple = vfx.fadeout(multiple, 2.0) # fade out
multiple.write_videofile("toy_plane_multiple.mp4")


## Customize Effects
# define map function
from math import sin, pi
time_line_map = lambda t: t + 2*sin(pi/2*t)
duration = 4
# apply the map
sinusoidal = video.fl_time(time_line_map)
# set duration of new video
sinusoidal = sinusoidal.set_duration(duration)
# write result to file
sinusoidal.write_videofile('toy_plane_sin.mp4')

## Customize Images
# define process function
import numpy as np
def blink(get_frame, t):
  # frame is numpy array of size (height, width, 3)
  frame = get_frame(t) # get current frame
  # change lightness
  scale = (1+sin(t*pi))
  frame = frame*scale
  frame = frame.astype(np.int8) # convert to int8
  return frame

# apply function `blink`
blinking = video.fl(blink)
# write result to file
blinking.write_videofile('toy_plane_blink.mp4')
